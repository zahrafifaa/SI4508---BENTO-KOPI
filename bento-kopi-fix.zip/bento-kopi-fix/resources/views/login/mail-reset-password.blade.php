<h4>Halo, Anda diminta untuk mereset password, gunakan link dibawah ini untuk mereset password Anda</h4>
<br>
<br>
<a href="{{ route('validate-forgot-password',['token' => $token]) }}">Klik Disini</a>