<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #67BC67;">
    <div class="container">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" href="/">Bento Kopi</a>
          </li>
          <li class="nav-item">
            <a class="nav-link {{ ($active === "Home") ? 'active' : ''}}" href="/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link {{ ($active === "About") ? 'active' : ''}}" href="/about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link {{ ($active === "Blog") ? 'active' : ''}}" href="/blog">Blog</a>
          </li>
          <li class="nav-item">
            <a class="nav-link {{ ($active === "Categories") ? 'active' : ''}}" href="/categories">Categories</a>
          </li>
        </ul>

        
        <ul class="navbar-nav ms-auto">
          @auth
           <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Welcome back, {{ auth()->user()->username }}
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="/dashboard">My dashboard</a></li>
            <li><hr class="dropdown-divider"></li>
            <li>
              <form action="/logout" method="post">
                @csrf
                <button type="submit" class="dropdown-item"><a>Logout</a></button>
              </form>
          </ul>
        </li>
          @else
          <li class="naav-item">
            <a href="/login" class="nav-link {{ ( $active === "Posts") ? 'active' : '' }}"><i class="bi bi-box-arrow-in-right"></i>
              Login</a>
          </li>
          @endauth
        </ul>
      </div>
    </div>
  </nav>