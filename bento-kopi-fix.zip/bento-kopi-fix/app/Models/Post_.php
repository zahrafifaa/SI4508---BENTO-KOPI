<?php

namespace App\Models;

// use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Database\Eloquent\Model;

class Post 
{
    //properti statis
    private static $blog_posts = [
    [
        'title' => 'Judul Post Pertama',
        'slug' => 'judul-post-pertama',
        'author' => 'Aksanardian Alberami',
        'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo molestias illum nulla atque adipisci assumenda eos quibusdam fugiat! Consequuntur voluptate tempore ea sit accusantium nostrum fugiat eveniet ex voluptatem, veniam sunt, ipsum quia enim ratione dolor reprehenderit. Assumenda incidunt harum tempore qui maiores id laudantium? Est quae debitis itaque praesentium, velit cumque! Reprehenderit ab illum placeat quaerat facere dolor? Earum eligendi ea numquam, sapiente magnam quas voluptatum magni vitae sunt excepturi accusantium consequatur. Delectus voluptate quam, exercitationem fuga dolore, illum vero suscipit veniam similique minima in. Repellendus maxime cupiditate, itaque error ab voluptatibus sunt maiores aspernatur rerum earum, vero eveniet.'
    ],
    [
        'title' => 'Judul Post Kedua',
        'slug' => 'judul-post-kedua',
        'author' => 'Aksanardian Alberami',
        'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nesciunt ratione corrupti facere omnis nam non alias culpa delectus sequi debitis, distinctio consequuntur aspernatur provident modi minima cumque voluptatem natus nisi dignissimos, quo quibusdam id! Quos a, reprehenderit ea magnam repellendus alias. Repellendus quidem vero reprehenderit soluta quibusdam cumque atque. Modi.'
    ]
    ];

    public static function all()
    {
        return collect(self::$blog_posts);
    }

    public static function find($slug)
    {
        $posts = static::all();
        
        //ambil semua post yang bentuknya collection, cri yang pertama di temukan yang mana slug nya sama dengan slug
        return $posts->firstWhere('slug', $slug);
    }
}
