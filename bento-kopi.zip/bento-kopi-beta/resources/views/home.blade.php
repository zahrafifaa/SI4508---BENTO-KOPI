@extends('layouts.main')

@section('main')
    <h1>Halaman Home</h1>
@endsection