@extends('layouts.main')

@section('main')
<div class="main">
    <div class="form">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li> 
                    @endforeach
                </ul>
            </div>
        @endif
        @if(session()->has('status'))
            <div class="alert alert-success">
                {{ session()->get('status') }}
            </div>
        @endif

        <h2>Forgot password?</h2>
        <p>please enter ur email</p>
        <form action="{{ route('password.email') }}" method="post">
            @csrf
            <label for="email" class="form-label">email</label>
            <input type="email" class="form-control" name="email">
            <input type="submit" value="Request password reset" class="btn btn-primary w-100 mt-3">
        </form>
    </div>
</div>
@endsection