@extends('layouts.main')

@section('main')
<div class="main">
    <div class="form">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li> 
                    @endforeach
                </ul>
            </div>
        @endif
        @if(session()->has('status'))
            <div class="alert alert-success">
                {{ session()->get('status') }}
            </div>
        @endif

        <h2>Forgot password?</h2>
        <p>please enter ur email</p>
        <form action="{{ route('password.update') }}" method="post">
            @csrf
            <input type="hidden" name="token" value="{{ request()->token }}">
            <input type="hidden" name="email" value="{{ request()->email }}">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" name="password">
            <label for="password_confirmation" class="form-label">Password Confirmation</label>
            <input type="password" class="form-control" name="password_confirmation">
            <input type="submit" value="Update Password " class="btn btn-primary w-100 mt-3">
        </form>
    </div>
</div>
@endsection