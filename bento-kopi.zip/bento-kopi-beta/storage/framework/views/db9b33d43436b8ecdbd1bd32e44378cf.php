

<?php $__env->startSection('main'); ?>
    <h1>Halaman Home</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bento-kopi-beta\resources\views/home.blade.php ENDPATH**/ ?>