<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\bento-kopi-beta\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>