

<?php $__env->startSection('main'); ?>
<div class="main">
    <div class="form">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session()->has('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('status')); ?>

            </div>
        <?php endif; ?>

        <h2>Forgot password?</h2>
        <p>please enter ur email</p>
        <form action="<?php echo e(route('password.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e(request()->token); ?>">
            <input type="hidden" name="email" value="<?php echo e(request()->email); ?>">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" name="password">
            <label for="password_confirmation" class="form-label">Password Confirmation</label>
            <input type="password" class="form-control" name="password_confirmation">
            <input type="submit" value="Update Password " class="btn btn-primary w-100 mt-3">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bento-kopi-beta\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>