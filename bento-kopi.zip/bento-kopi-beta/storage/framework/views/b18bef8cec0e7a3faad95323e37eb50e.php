<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #67BC67;">
    <div class="container">
      <a class="navbar-brand" href="/">
        Bento Kopi</a>
      <button class="navbar-toggler " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">

        <ul class="navbar-nav ms-auto">
          <?php if(auth()->guard()->check()): ?>
           <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Welcome back, <?php echo e(auth()->user()->username); ?>

          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="/dashboard">My dashboard</a></li>
            <li><hr class="dropdown-divider"></li>
            <li>
              <form action="/logout" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit" class="dropdown-item"><a>Logout</a></button>
              </form>
          </ul>
        </li>
          <?php else: ?>
          <li class="naav-item">
            <a href="/login" class="nav-link <?php echo e(( $active === "Posts") ? 'active' : ''); ?>"><i class="bi bi-box-arrow-in-right"></i>
              Login</a>
          </li>
          <?php endif; ?>
        </ul>
        
      </div>
    </div>
  </nav>

  <?php /**PATH C:\xampp\htdocs\bento-kopi-beta\resources\views/partials/navbar.blade.php ENDPATH**/ ?>