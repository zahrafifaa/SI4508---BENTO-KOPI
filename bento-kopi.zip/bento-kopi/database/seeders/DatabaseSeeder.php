<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\Post;
use App\Models\User;
use App\Models\Category;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // \App\Models\User::factory(10)->create();

        User::create([
            'name' => 'Aksanardian Alberami',
            'email' => 'aksanardian@gmail.com',
            'password' => bcrypt('123')
        ]);

        User::create([
            'name' => 'Dody mei',
            'email' => 'aadoi@gmail.com',
            'password' => bcrypt('123')
        ]);

        Category::create([
            'name' => 'Web Programming',
            'slug' => 'web-programming'
        ]);

        Category::create([
            'name' => 'Personal',
            'slug' => 'personal'
        ]);

        Post::create([
            'active' => 'Judul Pertama',
            'slug' => 'judul-pertama',
            'excerpt' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex inventore illo cumque quis id velit dicta dolores obcaecati eum recusandae, optio incidunt corrupti deserunt natus expedita, doloremque illum quibusdam.',
            'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex inventore illo cumque quis id velit dicta dolores obcaecati eum recusandae, optio incidunt corrupti deserunt natus expedita, doloremque illum quibusdam. Harum quod dicta in voluptas quas, neque dolorum ullam veritatis! Voluptas at eos culpa iusto officiis id impedit repudiandae nulla nisi voluptates distinctio pariatur, animi placeat libero expedita dignissimos sit dolorum recusandae laboriosam ad odio quibusdam nihil ex. Provident laborum fugiat at possimus suscipit, odit numquam sint consectetur natus voluptatibus, recusandae cupiditate. Pariatur quis excepturi debitis numquam, sunt assumenda omnis iste! Non nulla esse nostrum corrupti deserunt cum natus, quia quae.',
            'category_id' => 1,
            'user_id' => 1
        ]);

        Post::create([
            'active' => 'Judul Kedua',
            'slug' => 'judul-ke-dua',
            'excerpt' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex inventore illo cumque quis id velit dicta dolores obcaecati eum recusandae, optio incidunt corrupti deserunt natus expedita, doloremque illum quibusdam.',
            'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex inventore illo cumque quis id velit dicta dolores obcaecati eum recusandae, optio incidunt corrupti deserunt natus expedita, doloremque illum quibusdam. Harum quod dicta in voluptas quas, neque dolorum ullam veritatis! Voluptas at eos culpa iusto officiis id impedit repudiandae nulla nisi voluptates distinctio pariatur, animi placeat libero expedita dignissimos sit dolorum recusandae laboriosam ad odio quibusdam nihil ex. Provident laborum fugiat at possimus suscipit, odit numquam sint consectetur natus voluptatibus, recusandae cupiditate. Pariatur quis excepturi debitis numquam, sunt assumenda omnis iste! Non nulla esse nostrum corrupti deserunt cum natus, quia quae.',
            'category_id' => 1,
            'user_id' => 1
        ]);

        Post::create([
            'active' => 'Judul Ke Tiga',
            'slug' => 'judul-ke-tiga',
            'excerpt' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex inventore illo cumque quis id velit dicta dolores obcaecati eum recusandae, optio incidunt corrupti deserunt natus expedita, doloremque illum quibusdam.',
            'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex inventore illo cumque quis id velit dicta dolores obcaecati eum recusandae, optio incidunt corrupti deserunt natus expedita, doloremque illum quibusdam. Harum quod dicta in voluptas quas, neque dolorum ullam veritatis! Voluptas at eos culpa iusto officiis id impedit repudiandae nulla nisi voluptates distinctio pariatur, animi placeat libero expedita dignissimos sit dolorum recusandae laboriosam ad odio quibusdam nihil ex. Provident laborum fugiat at possimus suscipit, odit numquam sint consectetur natus voluptatibus, recusandae cupiditate. Pariatur quis excepturi debitis numquam, sunt assumenda omnis iste! Non nulla esse nostrum corrupti deserunt cum natus, quia quae.',
            'category_id' => 2,
            'user_id' => 1
        ]);

        Post::create([
            'active' => 'Judul Ke Empat',
            'slug' => 'judul-ke-empat',
            'excerpt' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex inventore illo cumque quis id velit dicta dolores obcaecati eum recusandae, optio incidunt corrupti deserunt natus expedita, doloremque illum quibusdam.',
            'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex inventore illo cumque quis id velit dicta dolores obcaecati eum recusandae, optio incidunt corrupti deserunt natus expedita, doloremque illum quibusdam. Harum quod dicta in voluptas quas, neque dolorum ullam veritatis! Voluptas at eos culpa iusto officiis id impedit repudiandae nulla nisi voluptates distinctio pariatur, animi placeat libero expedita dignissimos sit dolorum recusandae laboriosam ad odio quibusdam nihil ex. Provident laborum fugiat at possimus suscipit, odit numquam sint consectetur natus voluptatibus, recusandae cupiditate. Pariatur quis excepturi debitis numquam, sunt assumenda omnis iste! Non nulla esse nostrum corrupti deserunt cum natus, quia quae.',
            'category_id' => 2,
            'user_id' => 2
        ]);

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
