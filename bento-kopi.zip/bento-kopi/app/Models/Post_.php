<?php

namespace App\Models;


class Post 
{
    private static $blog_posts = [
            [
                "active" => "Judul Post Pertama",
                "slug" => "judul-post-pertama",
                "author" => "Malik",
                "body" => "Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem nesciunt cumque beatae explicabo, hic atque iure! Praesentium ab neque iusto odit magnam eum soluta provident dolore, eaque beatae dolorem at!"
            ],
            [
                "active" => "Judul Post Kedua",
                "slug" => "judul-post-kedua",
                "author" => "Dodir",
                "body" => "Lorem ipsum dolor sit am et consectetur, adipisicing elit. Perspiciatis aspernatur pariatur et, saepe autem hic blanditiis omnis iusto doloribus eaque iste quasi molestiae officiis! Doloribus eaque harum recusandae error quod explicabo dignissimos quam facere voluptate eius, dolore eos corporis. Aut doloribus labore ut consectetur voluptatem, reiciendis modi molestiae officiis voluptates rerum quaerat voluptatum non. Optio, eius esse? Omnis et sed minima quidem dicta cum impedit ea iure aperiam nulla! Harum ipsam aperiam cupiditate eius quam? Laborum architecto, soluta error delectus ipsa incidunt. Suscipit blanditiis in, dicta quam expedita reprehenderit impedit deserunt saepe eaque sed distinctio eum vero beatae quibusdam culpa?"
            ]

        ];

    public static function all()
    {
        return collect(self::$blog_posts);
    }

    public static function find($slug)     
    {
        $posts = static::all();     
        // $post = [];
        // foreach($posts as $p) {
        //     if ($p['slug'] === $slug) {
        //         $post = $p;
    
        //     }
        // }

        return $posts->firstWhere('slug', $slug);
    }
}
