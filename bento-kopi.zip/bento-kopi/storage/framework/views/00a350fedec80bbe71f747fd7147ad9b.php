<h4>Halo, Anda diminta untuk mereset password, gunakan link dibawah ini untuk mereset password Anda</h4>
<br>
<br>
<a href="<?php echo e(route('validate-forgot-password',['token' => $token])); ?>">Klik Disini</a><?php /**PATH C:\xampp\htdocs\bento-kopi\resources\views/login/mail-reset-password.blade.php ENDPATH**/ ?>