<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    
    <link rel="stylesheet" href="/css/style.css">
    <title>Bento Kopi | <?php echo e($active); ?></title>
</head>
<body>
  
  <div class="row">
    
    <div class="col-lg-4" style="background-color: #67BC67; height: 97vh;">
      <div class="text-center mt-5 pt-5" >
        <img src="img/bentokopi.jpg" width="200px" class="rounded" alt="...">
        <h1 class="fw-bold" style="font-family:Poppins; color:white;">BentoKopi</h1>
      </div>
    </div>
    

    
    <div class="col-lg-8 ">
      <div class="container form mt-5 pt-5">
        <main class="form-registration w-100">
          <h1 class="h3 fw-normal">Daftar</h1> 
            <small class="d-block mt-3 mb-3">Sudah punya akun? <a href="/login">Masuk</a></small>
            
              <form action="/register" method="post">
                <?php echo csrf_field(); ?>
                <!-- Baris Pertama -->
                <div class="row gx-3 mb-3 ">
                  <!-- Form Nama Lengkap -->
                  <div class="col-md-6">
                    <label class="small mb-1" for="inputFirstName">Nama lengkap</label>
                      <div class="form-floating">
                        <input type="text" name="name" class="form-control rounded-top <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" placeholder="Name"  value="<?php echo e(old('name')); ?>">
                        <label for="name">Masukkan nama</label>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                          </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  <!-- Form Nama Pengguna)-->
                  <div class="col-md-6">
                    <label class="small mb-1" for="inputFirstName">Nama Pengguna</label>
                      <div class="form-floating">
                        <input type="text" name="username" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" placeholder="Username" value="<?php echo e(old('username')); ?>"> 
                        <label for="name">Masukkan Nama Pengguna</label>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                          </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
              </div>
              <!-- Baris Kedua -->
              <div class="row  gx-3 mb-3">
                <!-- Form Email -->
                <div class="col-md-6">
                  <label class="small mb-1" for="inputFirstName">Email</label>
                    <div class="form-floating">
                      <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="name@example.com" value="<?php echo e(old('email')); ?>">
                      <label for="email">Masukkan Email </label>
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                          <?php echo e($message); ?>

                        </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Form Password -->
                <div class="col-md-6">
                  <label class="small mb-1" for="inputFirstName">Password</label>
                    <div class="form-floating">
                      <input type="password" name="password" class="form-control rounded-bottom <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="Password">
                      <label for="password">Masukkan Password</label>
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                          <?php echo e($message); ?>

                        </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                    </div>
                </div>
              </div>
              
              <button class="btn btn-primary mt-3" type="submit">Daftar</button>
            </form>
        </main>
      </div>
    </div>
    
  </div>
  
</body>
</html>

<?php /**PATH C:\xampp\htdocs\bento-kopi\resources\views/register/index.blade.php ENDPATH**/ ?>