<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\Post;
use App\Models\Category;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        User::create([
            'name' => 'adminCashier ',
            'username' => 'Cashier ',
            'email' => 'adminCashier@gmail.com',
            'password' => bcrypt('123456')
        ]);

        User::create([
            'name' => 'user ',
            'username' => 'User1 ',
            'email' => 'user1@gmail.com',
            'password' => bcrypt('123456')
        ]);

        User::create([
            'name' => 'adminApp ',
            'username' => 'App ',
            'email' => 'adminApp@gmail.com',
            'password' => bcrypt('123456')
        ]);

        User::factory(3)->create();

        Category::create([
            'name' =>'Web Programming',
            'slug' =>'web-programming' 
        ]);

        Category::create([
            'name' =>'Web Design',
            'slug' =>'web-design' 
        ]);

        Category::create([
            'name' =>'Personal',
            'slug' =>'personal' 
        ]);

        Post::factory(20)->create();

        // Post::create([
        //     'title' => 'Judul Pertama',
        //     'slug' => 'judul-pertama',
        //     'excerpt' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus quidem beatae ducimus provident eos omnis ut doloribus dolor molestiae, atque nulla. Deleniti quam ea nulla. Ratione consectetur voluptatem distinctio repudiandae doloremque, recusandae exercitationem deserunt, odio nam officia aperiam. Fuga aperiam numquam laborum esse quisquam voluptatum aliquid quod minus, qui ex necessitatibus voluptates molestias! Omnis alias corrupti maxime aliquid. Error, ad modi! Quos numquam velit nobis repudiandae sapiente deserunt, cupiditate praesentium architecto provident nemo voluptates doloribus? Aut deleniti dignissimos adipisci quam.',
        //     'category_id' => 1,
        //     'user_id' => 1
        // ]);
        
        // Post::create([
        //     'title' => 'Judul Kedua',
        //     'slug' => 'judul-kedua',
        //     'excerpt' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus quidem beatae ducimus provident eos omnis ut doloribus dolor molestiae, atque nulla. Deleniti quam ea nulla. Ratione consectetur voluptatem distinctio repudiandae doloremque, recusandae exercitationem deserunt, odio nam officia aperiam. Fuga aperiam numquam laborum esse quisquam voluptatum aliquid quod minus, qui ex necessitatibus voluptates molestias! Omnis alias corrupti maxime aliquid. Error, ad modi! Quos numquam velit nobis repudiandae sapiente deserunt, cupiditate praesentium architecto provident nemo voluptates doloribus? Aut deleniti dignissimos adipisci quam.',
        //     'category_id' => 1,
        //     'user_id' => 1
        // ]);
        
        // Post::create([
        //     'title' => 'Judul Ketiga',
        //     'slug' => 'judul-ketiga',
        //     'excerpt' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus quidem beatae ducimus provident eos omnis ut doloribus dolor molestiae, atque nulla. Deleniti quam ea nulla. Ratione consectetur voluptatem distinctio repudiandae doloremque, recusandae exercitationem deserunt, odio nam officia aperiam. Fuga aperiam numquam laborum esse quisquam voluptatum aliquid quod minus, qui ex necessitatibus voluptates molestias! Omnis alias corrupti maxime aliquid. Error, ad modi! Quos numquam velit nobis repudiandae sapiente deserunt, cupiditate praesentium architecto provident nemo voluptates doloribus? Aut deleniti dignissimos adipisci quam.',
        //     'category_id' => 2,
        //     'user_id' => 1
        // ]);
        
        // Post::create([
        //     'title' => 'Judul Keempat',
        //     'slug' => 'judul-keempat',
        //     'excerpt' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus quidem beatae ducimus provident eos omnis ut doloribus dolor molestiae, atque nulla. Deleniti quam ea nulla. Ratione consectetur voluptatem distinctio repudiandae doloremque, recusandae exercitationem deserunt, odio nam officia aperiam. Fuga aperiam numquam laborum esse quisquam voluptatum aliquid quod minus, qui ex necessitatibus voluptates molestias! Omnis alias corrupti maxime aliquid. Error, ad modi! Quos numquam velit nobis repudiandae sapiente deserunt, cupiditate praesentium architecto provident nemo voluptates doloribus? Aut deleniti dignissimos adipisci quam.',
        //     'category_id' => 2,
        //     'user_id' => 1
        // ]);
        

    }
}
