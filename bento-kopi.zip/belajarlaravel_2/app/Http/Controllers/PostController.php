<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index()
    {
        return view('blog',[
            'title' => 'All Posts',
            'active' => 'Blog',
            // 'posts' => Post::all()
            // 'posts' => Post::latest()->get()
            'posts' => Post::latest()->filter(request(['search']))->get()
        ]);
    }

    public function show(Post $post)
    {
        return view('post',[
            'title' => 'Single Post',
            'active' => 'Blog',
            'post' => $post
        ]);
    }
}
